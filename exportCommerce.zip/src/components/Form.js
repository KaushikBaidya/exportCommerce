import React from "react";
import { useRef, useState } from "react";
import emailjs from "@emailjs/browser";
import { useTranslation } from "react-i18next";

const Form = ({ title = "" }) => {
  const form = useRef();
  const { t } = useTranslation(["contact"]);
  const [done, setDone] = useState(false);
  const send = (e) => {
    e.preventDefault();
    emailjs
      .sendForm(
        "service_1caltje",
        "template_clw0189",
        form.current,
        "3TU1Pd0ABt2oTCuC-"
      )
      .then(
        (result) => {
          // console.log(result.text);
          setDone(true);
        },
        (error) => {
          // console.log(error.text);
        }
      );
  };
  return (
    <form className="mt-10" ref={form} onSubmit={send}>
      {title && (
        <div>
          <label>{title}</label>
          <input type="hidden" name="product_title" value={title} />
        </div>
      )}
      <input
        className="input"
        type="text"
        name="user_name"
        placeholder={t("name")}
      />
      <input
        className="input"
        type="text"
        name="user_email"
        placeholder={t("email")}
      />
      <input
        className="input"
        type="number"
        name="user_phone"
        placeholder={t("phone")}
      />
      <input
        className="input"
        type="text"
        name="user_subject"
        placeholder={t("subject")}
      />
      <textarea
        className="textarea"
        rows="5"
        name="message"
        placeholder={t("your-message")}
      />
      <button className="button hover:bg-[#f8982b]" type="">
        {t("button")}
      </button>

      {done && (
        <div className="bg-green-400 text-white p-3 my-3 rounded-lg ">
          {t("message")}
        </div>
      )}
    </form>
  );
};

export default Form;
