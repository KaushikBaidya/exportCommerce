const data = [
  {
    id: "1",
    title: "Wood pellets",
    // price: "$12/ Kilogram",
    img: "images/gallery/pellets.jpg",
  },
  {
    id: "2",
    title: "Rice husk briquettes",
    // price: "$12/ Kilogram",
    img: "images/gallery/ricehusk.jpg",
  },
  {
    id: "3",
    title: "Sawdust briquettes",
    // price: "$12/ Kilogram",
    img: "images/gallery/sawdust.jpg",
  },
  {
    id: "4",
    title: "Bamboo sawdust briquette",
    // price: "$12/ Kilogram",
    img: "images/gallery/bamboo.jpg",
  },
  {
    id: "5",
    title: "Charcoal (coconut shell/ bamboo/ sawdust) ",
    // price: "$12/ Kilogram",
    img: "images/gallery/charcoal.jpg",
  },
  {
    id: "6",
    title: "Chip block (wooden chip block pallets foot) ",
    // price: "$12/ Kilogram",
    img: "images/gallery/chipblock.jpg",
  },
];

export default data;
